/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.espol.rentalsystemtest;

/**
 *
 * @author quint
 */
public class Main {

    public static void main(String[] args){
    
      Customer c = new Customer("Kevin");
      c.addMovieRental(new MovieRental(new Movie("Groot",20),10));
        System.out.println(c.statement());
  
}
}
