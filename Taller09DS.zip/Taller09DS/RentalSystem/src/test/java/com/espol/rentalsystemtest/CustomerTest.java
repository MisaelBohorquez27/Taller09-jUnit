/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.espol.rentalsystemtest;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author quint
 */
public class CustomerTest {
    
    public CustomerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addMovieRental method, of class Customer.
     */
    @Test
    public void testAddMovieRental() {

 
    
    
    
    System.out.println("addMovieRental");
        MovieRental arg = new MovieRental(new Movie("Groot",20),10);
        Customer instance = new Customer("Kevin");
        instance.addMovieRental(arg);
        assertNotNull("Prueba ejecutada",arg);
        // TODO review the generated test code and remove the default call to fail.
        //fail("Pelicula en null no se puedo insertar");
    }

 

    /**
     * Test of addVideoGameRental method, of class Customer.
     */
    @org.junit.Test
    public void testAddVideoGameRental() {
        System.out.println("addVideoGameRental");
        VideoGameRental arg = new VideoGameRental("Ps3Game",4,true);
        Customer instance = new Customer("Kevin");
        instance.addVideoGameRental(arg);
        assertNotNull("Prueba ejecutada",arg);
        // TODO review the generated test code and remove the default call to fail.
        //fail("videojuego en null no se puede insertar");
    }

 

    /**
     * Test of statement method, of class Customer.
     */
    @org.junit.Test
    public void testStatement() {
        System.out.println("statement");
        Customer instance = new Customer("Kevin");
        String expResult = "Rental Record for Kevin\n Amount owed is 0.0\n You earned 0.0  frequent renter points";
        String result = instance.statement();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}
